/* COMP 3311: lab5Queries.sql */

-- Student id: 
-- Name: 

/******************************************************************************/
/***            USE ONLY SQL CONSTRUCTS DISCUSSED IN THE COURSE             ***/
/***   MOREOVER, FOR EACH QUERY IN THIS EXERCISE YOU MUST USE ONE OR MORE   ***/
/***  OF THE ANALYTIC FUNCTIONS DISCUSSED IN THE NOTES FOR THIS LAB AND YOU ***/
/***       MUST NOT CREATE ANY TEMPORARY RELATION USING A WITH CLAUSE.      ***/
/***     NO MARKS WILL BE GIVEN IF THESE REQUIREMENTS ARE NOT FOLLOWED.     ***/
/*** ---------------------------------------------------------------------- ***/
/***       Your queries will be tested by executing them against the        ***/
/***                            lab5db database.                            ***/
/***  If any query raises an SQL error or uses SQL constructs not discussed ***/
/***  in the lectures or labs, then your exercise mark will be at most 0.5. ***/
/******************************************************************************/

--------------------------------------------------------------------------------
/* Query 1: Find the rank of the students in the Department of Management 
            (MGMT) with respect to their cga.
            Include in the query result tuples attributes student name 
            (formatted as: last, first), their cga and rank.
            Order the query result tuples from highest to lowest rank. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 2: Find, based on their average grade, the quartile into which each 
            student in the Department of Computer Science and Engineering (COMP) 
            falls.
            Include in the query result tuples attributes student name 
            (formatted as: last, first), average grade and quartile into 
            which the student falls.
            Order the result first by quartile (highest to lowest average grade)
            and then by average grade descending. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 3: Find the enrolled courses for each student in the Department of 
			Computer Science and Engineering (COMP). 
            Include in the query result tuples attributes student name 
            (formatted as: last, first), courses, which is a comma-separated 
            list in ascending order of the student's course ids, and total 
            credits, which is the student's total course credits.
            Order the query result tuples first by total credits descending and 
            then by last name ascending. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 4: Find students in HUMA 1020 whose grade is above the course average 
            grade. 
            Include in the query result tuples attributes student name 
            (formatted as: last, first), unit id, grade, course average grade 
            truncated to two decimal places and course median grade truncated to 
            two decimal places.
            Order the query result tuples by grade descending. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 5: Find the students in each course who have the three highest ranks 
			with respect to their course grade. 
			Include in the query result tuples attributes course id, student name 
			(first followed by last), unit id, grade, average grade truncated to 
			one decimal place and course rank.
            Order the query result tuples first by course id and then by course 
            rank. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
