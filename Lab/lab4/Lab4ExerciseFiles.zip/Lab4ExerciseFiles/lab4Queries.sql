/* COMP 3311: lab4Queries.sql */

-- Student id: 
-- Name: 

/******************************************************************************/
/***    USE ONLY SQL CONSTRUCTS DISCUSSED IN THE LECTURES OR LABS SO FAR    ***/
/*** ---------------------------------------------------------------------- ***/
/***       Your queries will be tested by executing them against the        ***/
/***                            lab4db database.                            ***/
/***  If any query raises an SQL error or uses SQL constructs not discussed ***/
/***  in the lectures or labs, then your exercise mark will be at most 0.5. ***/
/******************************************************************************/

--------------------------------------------------------------------------------
/* Query 1: Find the minimum, maximum, average and median grade over all courses 
			truncated to two decimal places as well as the number of unique 
            students enrolled in all courses. */
-- <<< Place your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 2: Find, for each academic unit that has students, the unit name and 
            the average cga of the students in the unit truncated to two decimal 
            places.
            Order the query result tuples by average cga descending. */
-- <<< Place your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 3: Find, for each course, the students who have the highest cga and 
			the students who have the lowest cga in the course. 
			Include in the query result tuples attributes course id, student 
			last and first name, academic unit name, grade and cga.
			Order the query result tuples first by course id ascending, then by 
			cga descending and then by grade descending. */
-- <<< Place your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 4: Find, for students enrolled in the Department of Computer Science 
			and Engineering, the number of courses in which the student is 
			enrolled. 
			Include in the query result tuples attributes first name, last name 
			and the number of courses in which the student is enrolled.  
			Students not enrolled in any course should be included in the query 
			result and their number of enrolled courses should be shown as 0.
            Order the query result tuples first by the number of courses 
            descending and then by last name ascending. */
-- <<< Place your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------

/* Query 5: Find the cga, first name, last name and email of the students who 
			have the lowest cga and also find the course name, course id and 
			grade of the courses, if any, in which the student has the lowest 
			course grade. 
            Order the result first by last name ascending and then by grade 
            descending. */
-- <<< Place your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
