/* COMP 3311: L11Exercises5-7.sql */

-- Student id: 
-- Name: 

/******************************************************************************/
/***     USE ONLY SQL CONSTRUCTS DISCUSSED IN THIS AND PREVIOUS LECTURES    ***/
/***     Upload this completed script file to Canvas by 6 p.m. tomorrow.    ***/
/*** ---------------------------------------------------------------------- ***/
/***       Your queries will be tested by executing them against the        ***/
/***                         bookstoredb database.                          ***/
/***  If any query raises an SQL error or uses SQL constructs not discussed ***/
/***      in the course, then your exercise mark will be at most 0.5.       ***/
/******************************************************************************/

--------------------------------------------------------------------------------
/* Exercise 5:  Find the authors who wrote books on exactly three different 
                subjects. 
                Include in the query result tuples attributes author name (first 
                followed by last). 
                Order the query result tuples by last name ascending.
DO NOT use subqueries. DO NOT create any derived/temporary relations. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Exercise 6:  Find the customers who placed at least three orders in 2025. 
                Include in the query result tuples attributes last name and 
                number of orders.
                DO NOT use subqueries. DO NOT create derived/temporary relations. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Exercise 7:  Find customers who ordered the first and second highest total 
                number of books. 
                Include in the query result tuples attributes customer name (first 
                followed by last), total number of books ordered, and overall 
                total number of books ordered by all customers. 
                Order the query result tuples first by total number of books a 
                customer ordered descending and then by last name ascending. */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------