/* COMP 3311: L12Exercises5-7.sql */

-- Student id: 
-- Name: 

/******************************************************************************/
/***     USE ONLY SQL CONSTRUCTS DISCUSSED IN THIS AND PREVIOUS LECTURES.   ***/
/***     MOREOVER, FOR EACH QUERY IN THIS EXERCISE YOU MUST USE ONE OR      ***/
/***      MORE OF THE SQL JSON FUNCTIONS DISCUSSED IN THIS LECTURE AND      ***/
/***     YOU MUST NOT CREATE ANY TEMPORARY RELATION USING A WITH CLAUSE.    ***/
/***     NO MARKS WILL BE GIVEN IF THESE REQUIREMENTS ARE NOT FOLLOWED.     ***/
/*** ---------------------------------------------------------------------- ***/
/***       Your queries will be tested by executing them against the        ***/
/***                      boatReservationsdb database.                      ***/
/***         If any of the queries raises an SQL error or if you use        ***/
/***        SQL constructs not discussed in this or previous lectures,      ***/
/***        then you will receive at most 0.5 marks for this exercise.      ***/
/******************************************************************************/

--------------------------------------------------------------------------------
/* Exercise 5:  Construct a JSON object for each sailor who has reserved a boat 
                with fields sailor id, name and reservations whic is an array 
                field whose values are objects, one for each of the sailor's 
                reservations, with fields boat id, boat name and boat type. 
                Order the query result objects by sailor id ascending. */
-- <<< Construct the SQL query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Exercise 6:  Construct a JSON object for each boat with fields all the 
                attributes of Boat and reservations which is an array field 
                whose values are objects, one for each of the boat's 
                reservations, with fields sailor id, sailor name and rating. 
                If a boat has never been reserved, then the reservations field 
                should be absent. */
-- <<< Construct the SQL query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Exercise 7:	Construct a JSON object for each sailor with fields all the 
                attributes of Sailor and reservations which is an array field 
                whose values are objects, one for each of the sailor's 
                reservations, with fields boat id and reservation date; if a 
                sailor has not reserved any boat, then the "reservations" field 
                should be absent. 
                The reservation date format should be the same as in the Reserves 
                relation, i.e., DD-MON-YY. */
-- <<< Construct the SQL query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
