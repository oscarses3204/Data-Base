/* COMP 3311: sqlCreatedb.sql */

-- Name: 
-- Student id: 

/******************************************************************************
*                             IMPORTANT NOTE                                  *
*   You are allowed to use only SQL DDL constructs that have been discussed   *
*     in the course. If SQL DDL constructs that have not been discussed in    *
*       the course are used, then no marks will be given for this part.       *
*******************************************************************************/

--------------------------------------------------------------------------------
-- <<< Place your SQL DDL statements below this line >>>

