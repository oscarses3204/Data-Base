/* COMP 3311: sqlQueries.sql */

-- Name: 
-- Student id: 

/******************************************************************************
*                             IMPORTANT NOTE                                  *
*   You are allowed to use only SQL constructs that have been discussed in    *
*     the course. If SQL constructs that have not been discussed in the       *
*   course are used in a query, then no marks will be given for that query.   *
*                                                                             *
* >>> Do not use PL/SQL procedures or functions; use SQL statements only. <<< *
*******************************************************************************/

--------------------------------------------------------------------------------
/* Query 1: Find movies that have genres that are not a genre of any movie that 
            has been streamed. 
            Include in the query result tuples attributes movie title and all 
            their genres as a comma-separated list.
            Order the query result tuples by title ascending.
            [4 marks] */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 2: Find movies in which a cast member both appeared in and directed the 
            movie and the movie won both the Best Picture academy award and the 
            Best Director academy award.
            Include in the query result tuples attributes cast member/director 
            name, role he/she played, movie title and release year.
            Order the query result tuples first by cast member/director name 
            ascending and then by role ascending. 
            [6 marks] */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 3: Find the top ranked male actors based on the number of movies in 
            which the actor appeared that received the Best Picture academy 
            award.
            Include in the query result tuples attributes actor name and a 
            parenthesized, semicolon-separated list of the movie titles and 
            their release year for the movies that received the Best Picture 
            academy award in which the actor appeared.
            Order the query result tuples by actor name ascending. [8 marks] */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 4: Find movies that have been streamed the greatest number of times. 
            Include in the query result tuples attributes title, IMDB rating 
            and Reelflics rating truncated to one decimal place.
            Order the query result tuples by title ascending. [8 marks] */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 5: Find movies that won the Best Picture academy award, whose director 
            won the Best Director academy award for the movie, an actor won the 
            Best Actor academy award for the movie, and an actress won the Best 
            Actress academy award for the movie. 
            Include in the query result tuples attributes title, release year, 
            director name, actor name and actress name. 
            Order the query result tuples by title ascending. [12 marks] */
-- <<< Construct Query 4 below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
/* Query 6: Find movies that won the Best Picture academy award and that have 
            been streamed a greater number of times by different male members 
            than by different female members. Movies that have not been 
            streamed by anyone should be excluded from the query result.
            Include in the query result tuples attributes title, MPAA rating, 
            IMDB rating, Reelflics rating and number of times streamed. 
            Replace null ratings with the string 'no rating'.
            Order the query result tuples first by number of times streamed 
            descending and then by title ascending. [12 marks] */
-- <<< Construct your query below this line as a single SQL statement >>>



--------------------------------------------------------------------------------
